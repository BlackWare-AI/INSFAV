# INSFAV 5.0.0 — AMOLED Lists and Scroll Controls (Build 10)

- Main folder/account frames: black (#000), single 1px #111 borders, 26px outer corners. Interior rows remain square; the last account closes the lower frame.
- Existing avatars stay 67.5×67.5px with 14px corners. Rows remain 68px; widths, horizontal padding, fonts and bottom navigation are preserved.
- Long folder names truncate before the count and rotated arrow, including enlarged text.
- Fixed pale-gray up/down buttons and a draggable thumb fit entirely inside the existing right gutter. The main list is not narrowed.
- Buttons go to the real beginning/end of the entire main list, including every open folder; touch activation also handles a tap that stops an active fling. A jump settles for at most eight frames/150ms; new input cancels it immediately.
- Dragging requires a fresh 3-second hold on the thumb. Early release/movement cancels; the armed thumb glows. Release, interruption, resize, content changes and overlays relock it. Empty-track clicks do not jump.
- Scroll limits and thumb position follow actual document/viewport dimensions. Search-expanded accounts receive the same controls. Short/collapsed lists and overlays hide them.

Version 5.0.0 and build 10, the signing certificate, persistent index, source thumbnails, SAF, Fetcher, JSON handling and other screens are preserved. No new preference, image rewrite, redownload or queue reset is introduced.

Validation results and exact provenance are in verification.json and CHANGE-AND-TEST-REPORT.md. Browser and Android emulator fixtures are synthetic; no physical-device or live Instagram test is claimed.

Completed verification: CI 39956070667 passed 222 Android unit tests, 16 core tests, 134 existing UI checks, 53 scroll/AMOLED checks, lint (0 errors), and Android 14 emulator touch tests at system font scales 1.0/1.3/1.5. The signed APK payload matches that CI release exactly.
