# AMOLED liste ve kaydırma kontrolleri — değişiklik raporu

Kaynak: ef43bd407816fac523a84efbc152d9f9b69ec459
Uygulama 5.0.0, build 10; sürüm ve imza korunur.

| Dosya / metot | Önce | Yeni davranış | Test |
|---|---|---|---|
| web/style.css: folder-wrap, account, account.last | 20px dış köşeler ve farklı çerçeve renkleri | #000 arka plan, tek 1px #111 çizgi, 26px dış köşeler; açık klasörün üstü ve son hesabın altı çerçeveyi tamamlar | scroll-controls.cjs: renk, köşe, tek ayırıcı, 68px aralık, dar ekran |
| web/style.css: folder-header / folder-count / folder-arrow | Uzun ad ve büyük yazıda döndürülmüş ok sayıya taşabiliyordu | Okun konumu ve sol padding korunur; başlık içindeki 20px sütun boşluğu ve küçülmeyen sayı/ok çakışmayı önler | 280/320/393/600px ve 1.3/1.5 yazı testleri |
| web/app.js: mainScroll | Sabit başa/sona düğmesi ve tutularak sürüklenen çubuk yoktu | Mevcut sağ boşlukta 11px kontrol, gerçek sayfa sınırları, çoklu açık klasör ve arama desteği | Gerçek tarayıcı pointer/touch/keyboard olayları; 20.000 hesap |
| mainScroll: pointerdown/move/up/cancel | Tutma kilidi yoktu | Her sürüklemede 3000ms tutma; önceki 8px hareket iptal; aktif parlama; bırakma ve kesintilerde kilit | Sahte saatle 2999/3000ms; erken bırakma, kaydırma uçları, pointer cancel, resize ve modal |
| mainScroll: düğme etkinleştirme | Hızlı dokunmatik kaydırmayı durduran ilk dokunuşta Chrome click üretmiyor | Touch pointerup da düğmeyi çalıştırır; son compositor hareketine karşı en çok 8 frame/150ms hedef korunur; yeni giriş anında iptal eder; klavye click davranışı korunur | Aktif fling sırasında gerçek touch tap ile başa dönme |
| web/app.js: rebuild / renderVisible | Yalnızca sanal satırlar güncelleniyordu | İçerik değişiminde eski tutma iptal edilir; mevcut rAF akışı kontrol geometrisini günceller | Kapama, arama, boş/kısa liste, modal dönüşü; DOM sınırları |
| web/core.js: scrollMetrics / dragScrollTarget | Ayrı çubuk geometrisi yoktu | Sonlu gerçek aralık, orantılı gösterge ve her iki uçta clamp | Core birim testleri: sıfır/kısa/uzun liste, küçük track, geçersiz boyutlar |
| ScrollDeviceChecks / PoolInstrumentation / emulator-pool.sh | Bu özellik için Android dokunma kanıtı yoktu | 4.000 sentetik hesapta gerçek Android giriş olayları, 1.0/1.3/1.5 sistem font ölçeği; ayar ve belge geri yüklenir | Emülatör sonucu ve scroll-ui.json; ekran görüntüsü |
| android.yml ve üretilmiş asset/map/manifest | Eski paket ve test adımları | Deterministik web üretimi, yeni tarayıcı testi ve emülatör kanıtının dışa aktarılması | CI kaynak/paket eşliği, unit/lint, emülatör |

## Korunan davranışlar

Avatar 67.5px / 14px köşe; satır 68px; yatay padding, yazı ölçüleri, alt bar ve 14px klasör arası boşluk korunur. Yeni satır margin/gap/spacer yoktur. rowsFor, offsets ve overscan hesapları değişmez. Kontrol DOM'u sabittir; bütün hesaplar DOM'a yüklenmez. Global renk değişkeni ve diğer ekranların stilleri değiştirilmez.

Kalıcı indeks ve uygulama Java üretim kodu değişmedi. Kaynak görsellere dokunulmaz; 128/256 WebP, JSON, SQLite, SAF, Fetcher ve mevcut kullanıcı kayıtları aynı kalır. Yeni Android bridge komutu, bağımlılık veya seçenek eklenmez.

## Kanıt ve sınırlamalar

Yerel: 222 Android unit testi, 16 core testi, 134 mevcut UI kontrolü ve 53 yeni kaydırma/AMOLED kontrolü başarılı. Lint: 0 hata, 31 mevcut uyarı. Tam kaynak CI ve emülatör sonuçları verification.json içinde ayrıca kaydedilir.

İlk dar ekran/büyük yazı testi ok-sayı çakışmasını gösterdi; başlıktaki alan ayrımıyla düzeltildi. Hızlı touch kaydırma testi, Chrome'un ilk dokunuşta click'i bastırdığını gösterdi; touch pointerup işlenerek düzeltildi. Sahte saatli tutma testlerinde Web Animations otomatik ilerlemediği için reduced-motion kullanılır; normal animasyonlu modal açma/kapama ayrıca gerçek zamanla test edilir. Başarısız kontrol kaldırılmadı veya işlevsizleştirilmedi.

Kanıt düzeyleri: CODE_REVIEW, UNIT_TEST; başarılı emülatör koşusu varsa DEVICE_TEST. Tarayıcı native bridge'i ve profil verileri sentetiktir; emülatör de gerçek Instagram testi değildir. Fiziksel cihaz ve gerçek Instagram oturumu kullanılmadı. Kullanıcının liste genişliğini koruma tercihi nedeniyle kontrol alanı 11 CSS pikselidir.

İlk tam CI koşusu 39954331178, hızlı touch kaydırma sonrası son compositor güncellemesinin hedefi birkaç piksel bozması nedeniyle başarısız oldu; emülatör aşaması bu koşuda atlandı. Test kaldırılmadı. Sınırlı hedef koruması, viewport kimliği ve pointer kimliği kontrolleri eklendi. Yeni koşunun sonucu verification.json içinde ayrı kaydedilir.

## Nihai sonuç

CI 39956070667 (ef43bd407816fac523a84efbc152d9f9b69ec459) başarılı: 222 Android unit testi, 16 core testi, 134 mevcut UI ve 53 yeni kaydırma/AMOLED kontrolü. Lint 0 hata / 32 uyarı (yerelde 31). Android 14 emülatöründe 4.000 sentetik hesap, gerçek tap/hold/drag ve sistem font ölçekleri 1.0 / 1.3 / 1.5 başarılı; WebView textZoom değerleri 100 / 130 / 150 olarak ölçüldü. Kartlarla ve sağ kenarla 2px açıklık tüm ölçeklerde korundu. scroll-ui.json ve scroll-device-150.png bu koşuya aittir.

İmzalı APK, aynı CI koşusunun unsigned release içeriğiyle birebir eşleşir. Önceki avatar675 APK’sına göre yalnızca assets/app.js, assets/core.js, assets/style.css ve kaynak commit metadatası farklıdır; native uygulama içeriği aynıdır. Aynı sertifika, paket, 5.0.0 sürümü ve build 10 doğrulanır.
