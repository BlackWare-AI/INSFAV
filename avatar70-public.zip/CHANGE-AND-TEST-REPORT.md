# Liste ölçüleri değişiklik ve test raporu

Kaynak: e06e6e4a5b7825b6c4a0309943ab59e5b1457a9a
Uygulama: 5.0.0 / build 10 (değişmedi).

| Dosya / metot | Önce | Sonra | İlgili doğrulama |
|---|---|---|---|
| web/style.css, .avatar / .account | 40×40 avatar; 71px satır, 14px dikey padding | 70×70 avatar; 72px satır, 0 dikey padding; yatay padding ve kırpma korunur | browser.cjs: gerçek DOM ölçüleri, avatarın satıra sığması, ardışık satır aralığı |
| web/core.js, rowsFor() | Açık klasör 66px, kapalı klasör + boşluk 74px, hesap satırı 71px | Açık klasör 72px, kapalı klasör + boşluk 86px, hesap satırı 72px; klasörler arası 14px boşluk korunur | core.test.cjs: kapalı/açık/arama satırları ve tam offset dizisi; 1k/5k/10k liste sınırları |
| web/style.css, .card-name / .card-user | 15px / 13px | 19.5px / 16.9px (+%30) | browser.cjs: computed font-size |
| web/style.css, .folder-wrap / .folder-header | 60px kapalı, 66px açık dış alan | 72px açık ve kapalı klasör barı | browser.cjs: her iki durumun DOM yüksekliği |
| web/style.css, .folder-title / .folder-count | 14px / 10px | 18.2px / 13px (+%30) | browser.cjs: computed font-size ve yatay taşma |
| web/style.css, .folder-arrow | 26px, kapalıyken sağa | 36.4px (+%40), taban yönü 90° aşağı; mevcut açma dönüşüne aynı 90° ofset | browser.cjs: kapalı ok boyutu/dönüş matrisi; başlık DOM öğesi korunur |
| app/src/main/assets/core.js ve style.css; tools/web-bundle.json | Önceki üretilmiş paketler | Yukarıdaki kaynaklardan npm run web ile deterministik üretim | GitHub CI yeniden üretir, git diff --exit-code kontrolü |

Kalıcı indeks kaynak görsellerin gerçek boyutlarını tutar; 40×40 önizleme dosyaları oluşturmaz. 40px önceki CSS görüntüleme ölçüsüydü. Bu güncelleme liste görüntüleme ve sanal satır hesaplarını değiştirir; SQLite biçimi, SAF taraması, 128/256 WebP kaynak dosyaları ve Fetcher değişmez. Rescan kaynak görselleri yeniden boyutlandırmaz. Yeni seçenek eklenmedi.

Yerel sonuçlar: 12 JavaScript core testi, 132 Chromium UI kontrolü, 222 Android birim testi başarılı; hata/atlanan test yok. :app:testDebugUnitTest ve :app:lintDebug çalıştırıldı. Lint: 0 hata, 31 mevcut uyarı. GitHub: aynı 222 Android testi, 132 UI kontrolü ve 35 çevrimdışı probe fixture'ı başarılı; lint 0 hata, 32 uyarı (CI'daki ilave OldTargetApi uyarısı dahil).

APK uygulama içeriği önceki build 10 UI APK'sına göre yalnızca assets/core.js ve assets/style.css içinde değişir. İmza ve kaynak commit metadatası da doğal olarak farklıdır. Yayın APK'sının imza dışındaki ZIP içeriği GitHub CI unsigned APK'sıyla birebir karşılaştırılmıştır.

Kanıt düzeyleri: CODE_REVIEW, UNIT_TEST; tarayıcı testleri simüle native bridge kullanır. Emülatör sonucu verification.json içinde ayrıca kaydedilir. Fiziksel cihaz ve gerçek Instagram testi yapılmadı. Boyutlar CSS pikselidir; cihazın fiziksel piksel sayısı ekran yoğunluğuna bağlıdır.
