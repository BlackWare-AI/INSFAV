# INSFAV 5.0.0 — 70px list avatars (build 10 unchanged)

- List avatars: 70×70 CSS pixels; account rows: 72px.
- Folder bars: 72px, preserving the 14px gap between closed folders.
- Account display name and username: 19.5px / 16.9px (+30%).
- Folder name and count: 18.2px / 13px (+30%).
- Folder arrow: 36.4px (+40%), baseline rotated 90° down; existing expand transition retained with the same rotation offset.
- Virtual list offsets updated with the visible row sizes; no new preference.

Version 5.0.0 and versionCode 10 are unchanged. The release uses the same signing certificate as the previous build 10 UI APK.

The index stores source-image metadata, not 40×40 copies. The old 40px value was the list display size. Original 128/256 WebP files, scanner, source dimensions, persistent index, Fetcher, JSON import and settings behavior are unchanged. Rescan remains available; this display update does not require rewriting source images.

Validation: 12 JavaScript core tests and 132 Chromium UI checks passed locally. Android unit tests, lint and CI/emulator evidence are recorded separately in verification.json. Simulated bridge/fixture tests are not live Instagram tests. No physical device or live Instagram session was used for this update.
