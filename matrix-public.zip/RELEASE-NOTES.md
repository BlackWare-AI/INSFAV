INSFAV **5.0.0 / build 10** korunmuştur.

- Büyüyen, kullanılmadığında gizlenen kaydırma kontrolleri; **15 px kol, 100 ms tutma ve 480 ms gizlenme beklemesi**.
- Ayarların üstünde **Liste / Matris 2 / 3 / 4 / 5**; kare görsellerin altında kısaltılan @kullanıcıadı.
- Ayarların sağ üstünde kalıcı **TR / EN** seçimi; bildirim sunumu da seçilen dili izler.
- Eski zamanlayıcı/servis izinleriyle kendiliğinden başlamaya karşı mevcut sürece bağlı manuel başlatma kontrolü. Android süreci yeniden başlatırsa **Start Missing / Resume** gerekir; kayıtlı kuyruk ve sonuçlar korunur.
- Bilgi modalı, liste boyutları ve thumbnail dosya/indeks biçimleri korunmuştur.

Doğrulama: **231 Android birim testi, 22 çekirdek testi, 69 matris/dil ve 61 kaydırma kontrolü geçti; lint hatası yok.** Android 14 emülatöründe gerçek dokunma ve 1.0/1.3/1.5 sistem yazısı ile sentetik matris doğrulaması yapıldı. Gerçek Instagram ve fiziksel cihaz testi yapılmadı.

APK, kaynak ZIP, tek dosyada rapor + metin kaynak kodları ve test kanıtları ektedir.

Kaynak: `0f22a19613cbb7317b357c67bb69c1119376a530`  
APK SHA256: `6b53d37cbf174d79d9c56c624419977d4cc5dcf1d1ac70924bf35665d2da705a`
