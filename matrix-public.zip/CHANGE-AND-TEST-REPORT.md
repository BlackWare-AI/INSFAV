INSFAV 5.0.0 / BUILD 10 — TEKNİK DEĞİŞİKLİK VE TEST RAPORU

Kapsam: Kullanılabilir kaydırma kontrolleri, 2/3/4/5 sütunlu matris, kalıcı TR/EN seçimi ve açık kullanıcı isteği olmadan Fetcher başlatılmasının engellenmesi.

Mevcut liste satırı/klasör yüksekliği 68 px, liste avatarı 67.5 px ve avatar köşeleri 14 px kaldı. Alt bar ve Bilgi modalının içeriği/tasarımı korunmuştur. Matris için kaynak görseller yeniden oluşturulmaz; 128/256 WebP ve kalıcı indeks olduğu gibi kullanılır. Bu değişikliklerin parçası olarak rescan, yeniden indirme, dosya silme veya kuyruk kayıtlarını sıfırlama yapılmadı.

DOSYA / METOT / ESKİ-YENİ DAVRANIŞ / KANIT

1. web/core.js: rowsFor, scrollMetrics
Önce: Her hesap tek 68 px satırdı; scrollbar minimum yüksekliği 28 px idi.
Sonra: Varsayılan liste değişmez. Matris görselleri CSS aspect-ratio:1 kullanır; sanal hücre/satır ölçüleri aynı CSS ile çizilen görünmez bir grid satırından alınır. Seçime göre klasör hesapları 2/3/4/5 sütunlu sanal satırlara ayrılır. Hücreler eşit kare, son eksik satır da aynı boyuttadır. Metin satırı yüksekliği ölçülerek büyük sistem yazısında etiketin kırpılması önlenir. Minimum scrollbar yüksekliği 42 px.
Test: core.test.cjs (22 test), matrix-language.cjs. Kanıt: UNIT_TEST.

2. web/app.js: makeRow, rebuild, renderVisible, refreshAvatars, changeLayout, applyUiPreferences
Önce: Her sanal satırda tek avatar bulunuyordu.
Sonra: Matris satırındaki tüm avatarlar mevcut sınırlı yükleme/önbellek sistemine katılır ve görünümden çıkarken bırakılır. Kare görselin altında yalnızca @kullanıcıadı, tek satır ve ... bulunur. Görsele basma mevcut görüntüleyiciyi, kullanıcı adına basma profili açar. Görünüm/sütun/genişlik değişirken görünen hesap dayanak olarak korunur. Yeni seçenek veya dil seçimi indirme başlatmaz.
Test: matrix-language.cjs, Android ScrollDeviceChecks. Kanıt: UNIT_TEST, DEVICE_TEST (emülatör, sentetik veriler).

3. web/app.js: mainScroll; web/style.css
Önce: 11 px dar kontroller, 3 saniye tutma.
Sonra: İçi saydam 26×34 px düğmeler, %50 daraltılmış 7.5 px bar ve 15 px sola uzanan kol, 100 ms yeni tutma. Tutulunca parıltı. 480 ms kullanılmayınca opacity ile gizlenir; kaydırma/dokunma ile geri gelir. Klasör/liste genişliği değişmez; görünürken kenarın üzerinde geçici olarak dururlar. Düğmeler görünürken/gizlenirken hafif kayma animasyonu kullanır. Yukarı/aşağı gitme, yeni girdide iptal edilebilen 240–650 ms yumuşak kaydırma kullanır. Özel ray çizilmez; ana liste kontrolleri kullanılabilirken Android WebView native scrollbar boyaması kapatılır, ayarlarda geri açılır. Kısa, kapalı veya modalın arkasındaki listede gizlenir. Gerçek içerik sonuna bağlanır, sınırsız kayma yoktur. Erken hareket, pencere değişikliği, iptal ve bırakma tutmayı sıfırlar.
Test: scroll-controls.cjs (61 gerçek tarayıcı pointer kontrolü), Android dokunma testi. Kanıt: UNIT_TEST, DEVICE_TEST.

4. UiPreferences.java: read/save; MainActivity.Bridge; index.html; i18n.js; NotificationText.java; DownloadNotification
Önce: Dil ve matris tercihi yoktu.
Sonra: Ayarların üst sağında EN/TR, en üstte Liste/Matris 2/3/4/5 bulunur. Tercihler uygulamanın özel SharedPreferences alanına doğrulanarak kaydedilir. JSON, SAF ve thumbnail indeksine yazılmaz. Varsayılan İngilizce/Liste. Ayarlar, arama, Fetcher görünümü ve bildirim sunumu çevrilir. Dil ve görünüm seçimi ayrı siyah/#111 kenarlıklı/26 px köşeli AMOLED pencerelerde yapılır. Türkçe Fetcher başlığı Profil Görseli İndirici’dir; bildirim başlığı da çevrilir. Eksik görsel simgesi 27.6 px (%20 büyük), kopyalama SVG’si 18×26 px dikdörtgendir; 28×28 px kontrol ve bilgi kartı büyütülmez. Bilgi modalı değişmez; teknik hata kodları, tanılama ve tanınmayan sağlayıcı metinleri özgün kalır. Android sistem pencereleri cihazın sistem dilini izler. Yeni görünüm tercihleri mevcut şifreli ayar yedeği şemasına eklenmemiştir. Çeviri gözlemcisi sanal listeyi izlemez; görsel yükleme/kaydırma sırasında tüm metinleri yeniden taramaz.
Test: UiPreferencesTest, ManualRunTest.notificationLanguageChangesOnlyPresentation, matrix-language.cjs. Kanıt: UNIT_TEST.

5. ManualRun.java: reset/accepts/finish; Fetcher.initialize; FetchService.onStartCommand/request; QueueEngine.run
Önce: Kalıcı armed izni yeniden açılışta kullanılabiliyor; START_STICKY ile servis tekrar oluşturulabiliyor; yalnızca eski Retry Later kayıtları kalınca kuyruk zamanlayıcısı yetkili kalabiliyordu.
Sonra: Zamanlayıcı mevcut süreç tokenı ister; bu sayede Application.onCreate temizliğinden önce bile eski süreç izni reddedilir. Yeni uygulama sürecinde önceki çalışma izni kaldırılır ve eski işler iptal edilir. Servis null/eski süreç tokenı taşıyan isteği foreground bildirimi oluşturmadan reddeder. START_NOT_STICKY kullanılır. İşlenecek uygun hesap kalmayınca yetki kapatılır. Start Missing, Resume veya açık Retry eylemi yine kullanıcı tarafından başlatılır. Aynı süreçte kullanıcının başlattığı arka plan işi çalışma saatleri içinde sürebilir. Android süreci sonlandırırsa/cihaz yeniden başlarsa elle Start Missing veya Resume gerekir. Başarılı, atlanan, başarısız ve sonra denenecek sonuçlar korunur.
Test: ManualRunTest; kuyruk sonuçlarının birebir korunduğu, eski servis isteklerinin reddedildiği ve zamanlayıcı izninin kapandığı doğrulanır. Kanıt: CODE_REVIEW, UNIT_TEST. Kullanıcının cihazındaki tekil bildirimin nedeni gerçek cihaz diagnostics ile yeniden üretilmiş değildir; kodda bulunan olası yollar kapatılmıştır.

SINIRLAMALAR VE DÜRÜST TEST KAYDI
Gerçek Instagram erişimi ve fiziksel cihaz testi yapılmadı. Tarayıcı ve Android emülatörü testleri sentetik hesap/görseller kullanır. Ön kontrolde matris testinin bir sonraki sütun denemesinden önce ekran genişliğini sıfırlamadığı görüldü; fixture sıfırlaması düzeltildi, geometri beklentileri zayıflatılmadı. Gizlenme testinde fake clock kurulmadan yaratılan zamanlayıcı yerine yeni kullanıcı etkileşimiyle fake-clock zamanlayıcısı başlatıldı. Ön kaynak CI çalışmaları, çevirinin kaydırma performansını etkilememesi için yapılan son iyileştirmenin yeni çalışmalarıyla iptal edildi; nihai test sonuçları aşağıda belirtilen kaynak commitine aittir. Süreç tokenı şartı eklendikten sonra IntegrationQueueTest.pauseAndStopPersistWithoutDiscardingCompletedOrPendingWork testinin iki SDK varyantı başarısız oldu: eski fixture yalnızca armed bayrağıyla manuel başlatmayı taklit ediyordu. Fixture güncel süreç izniyle başlatıldı; pause/stop, kuyruk ve başarı kaydı beklentileri değiştirilmedi. Başarısız testler kaldırılmadı veya işlevsizleştirilmedi. Ek yerel Chromium 134 denemesi sayfa açılmadan TargetClosed ile kapandı; sistem Chromium 154 yerel kontrolleri ve GitHub Playwright Chromium 134 kontrolleri başarılıdır. Son UI isteği sırasında eksik-avatar fixture’ı eski profil eşlemesini vermeden yenilendiği için bir ön test placeholder beklerken zaman aşımı aldı; fixture önceki profili sağlayacak şekilde düzeltildi, ikon boyutu kontrolü korundu.


SON İSTEKLERİN DOĞRULAMA KAPSAMI
Önceki tam Android, tarayıcı ve emülatör doğrulaması c082a10f25bcc0af462398b003be414c5a1e9a41 / CI 39968135295 ile başarılıdır. Son ince ayarlar için tüm Android birim testleri ve lint yeniden çalıştırılır; değişen matris, dil, seçim pencereleri, kopyalama simgesi ve kaydırma kontrolleri tarayıcıda ve Android WebView emülatöründe yeniden doğrulanır. Kullanıcının isteği doğrultusunda değişmeyen Rescan/Fetcher/mesajlaşma/About performans fixture’ları bu son odaklı işte tekrar çalıştırılmaz. Testler kaldırılmadı; tam doğrulama workflow’u depoda duruyor.

Odaklı CI 39996099521: Android birim/lint ve 67+60 tarayıcı kontrolleri geçti; emülatör INSTRUMENTATION_FAILED ile yeni çalıştırıcıyı başlatamadı. APK manifest incelemesi Gradle’ın yalnızca yapılandırılmış PoolInstrumentation kaydını paketlediğini gösterdi. Ayrı çalıştırıcı yerine aynı PoolInstrumentation içinde scope=ui-refinement argümanı kullanıldı. Mevcut ve yeni testlerin doğrulamaları korunarak çalıştırma yolu düzeltildi; bu başarısız çalışma emülatör başarısı olarak raporlanmadı.

CI 39996933669: test çalıştırıcısı düzeldikten sonra emülatörde kontrollerin görünür olması beklentisi zaman aşımına uğradı. Eski 15 px kenar boşluğu koşulu artık kenar üzerinde duran yeni kontrol için gereksizdi; kaldırıldı. Sağ kenar koordinatı kesirli CSS ekran ölçüsünden alınır. Tarayıcıya kesirli geometri kontrolü eklendi. Android uç nokta doğrulaması doğal piksel yuvarlamasını 1 CSS px toleransla ele alır; son hesap/son konum kontrolleri korunur. Zaman aşımına güvenli yerleşim ölçümleri eklendi. Başarısız çalışma emülatör başarısı sayılmadı.

Kesirli matris fixture’ı düzeltmeden önce başarısız oldu: clientWidth tam sayıya yuvarlandığı için CSS grid genişliğiyle hesaplanan görsel yüksekliği arasında fark oluşuyordu. Gerçek getBoundingClientRect().width kullanıldı; aynı karelik beklentisiyle test geçti. Bu kontrol kaldırılmadı veya gevşetilmedi.

CI 39999166452: kaydırma görünürlüğü ve gerçek dokunma aşaması ilerledi; ardından Matrix cell geometry failed doğrulaması başarısız oldu. Gerçek genişlik kullanımına geçen karelik düzeltmesi bundan sonra uygulanıp aynı beklentiyle tekrar doğrulandı.

CI 39999868286 matris geometri kontrolünde tekrar başarısız oldu. Native test sütun sayısını dolu hücre adedinden çıkarmak yerine hesaplanan gridTemplateColumns düzeninden okur; son satırın eksik dolu olması geçerlidir. Pozitif ve seçilen sütun sayısını aşmayan hücre sayısı, karelik, etiket konumu, taşma ve isim gösterilmemesi beklentileri korunur. Ayrıntılı anonim hücre ölçümleri hata mesajına eklenir.

CI 40001332271 ayrıntılı ölçüm: 2 sütun, font ölçeği 1.0, hücre genişliği 178.33334 px, JS hesabıyla yükseklik 178.09525 px; yalnızca karelik false, etiket ve taşma kontrolleri true idi. CSS aspect-ratio:1 ile karelik doğrudan renderer’a verildi. Sanal satır yüksekliği görünmeyen bir gerçek grid satırıyla ölçülür; sabit border/padding varsayımı kullanılmaz. Aynı karelik eşiği korunur. Render border ölçümü ve sanal offsets için yeni testler eklendi.

Görsel kanıt sınırı: emülatörde matrix-device ve preference-device adlarıyla çekilen iki görüntü, DOM değişimi ile compositor karesi arasındaki gecikme nedeniyle Ayarlar ekranını gösteriyordu. Matris/modal görüntüsü diye kullanılmadı. Doğru içerikteki görüntü settings-device-150.png adıyla sunulur. Matris kareliği, seçimler ve dil kalıcılığı emülatörde DOM ölçümleri ve gerçek dokunmalarla doğrulanmıştır; tarayıcı matrix-ui.png ayrıca tarayıcı fixture görüntüsüdür.

Teslim altyapısı: package-verified dalı eski bir otomatik paketleme işini de tetikledi; bu iş yeni uygulama commitini eski sabitlemesiyle eşleşmediği için reddetti. Uygulama testleri değildir; güncel doğrulanmış kaynağa sabitlenen ayrı yayın işi kullanılır. Yayın denemesi 40004490036 imza/içerik/test kapılarından geçti, ancak GitHub sıfır baytlık crash.txt varlığını HTTP 400 Bad Content-Length ile reddetti. Orijinal boş log CI artifact içinde korunur; indirilebilir teslimde bunun açıkça üretildiği belirtilen crash-summary.txt bulunur. APK ve test sonuçları değiştirilmedi.

NİHAİ DOĞRULAMA
{
  "sourceCommit": "0f22a19613cbb7317b357c67bb69c1119376a530",
  "version": "5.0.0",
  "build": 10,
  "apkSha256": "6b53d37cbf174d79d9c56c624419977d4cc5dcf1d1ac70924bf35665d2da705a",
  "certificateSha256": "705e090084a4e50c47a8eb122d1605963276e5bb76f873d6f185b965c01e8641",
  "nativeTests": {
    "tests": 231,
    "failures": 0,
    "errors": 0,
    "skipped": 0
  },
  "coreTests": 22,
  "baselineBrowserChecks": 134,
  "scrollChecks": 61,
  "matrixChecks": 69,
  "baselineCiRun": 39968135295,
  "previousFocusedCiRun": 39996099521,
  "previousFocusedEmulatorConclusion": "failure: instrumentation runner not registered",
  "measuredGeometryCiRun": 40001332271,
  "measuredGeometryEmulatorConclusion": "failure: square dimensions 178.33334 vs 178.09525",
  "matrixGeometryCiRun": 39999166452,
  "matrixGeometryEmulatorConclusion": "failure: matrix cell geometry",
  "fractionalGeometryCiRun": 39996933669,
  "fractionalGeometryEmulatorConclusion": "failure: controls visibility timeout",
  "deviceScrollChecks": true,
  "ciRun": 40002877188,
  "ciConclusion": "success",
  "emulatorConclusion": "success",
  "physicalDeviceTested": false,
  "liveInstagramTested": false,
  "debuggable": false,
  "lintErrors": 0,
  "lintWarnings": 34,
  "signedReleaseInstalledOnDevice": false,
  "originalCrashLogBytes": 0
}

CI: https://github.com/BlackWare-AI/INSFAV/actions/runs/40002877188
Yerel ./gradlew :app:testDebugUnitTest ve :app:lintDebug başarılı. Release, aynı anahtarla imzalanmış CI APK içeriğine sahiptir. Emülatör debug APK kullanır; imzalı release APK fiziksel cihaza kurulmadı.
Lint hatası yoktur; uyarı sayısı yukarıdadır. Yeni iki ApplySharedPref uyarısı, çalışma yetkisinin iş başlamadan kalıcı olarak kapatılması için kullanılan senkron commit çağrılarıdır; uyarılar bastırılmadı.
