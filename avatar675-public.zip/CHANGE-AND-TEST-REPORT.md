# Değişiklik ve test raporu

Kaynak commit: a099d0a4b7def31b23ea3c1b5599a788240b304d

| Dosya / bölüm | Önce | Sonra | Test |
|---|---|---|---|
| web/core.js, rowsFor | Açık klasör ve hesap satırı 72; kapalı klasör + boşluk 86 | 68 / 82; mevcut 14px klasör boşluğu korunur | core.test.cjs: açma, kapama, arama ve tam offset dizisi; 1k/5k/10k hesap |
| web/style.css, .avatar ve .account | 70px avatar / 72px satır | 67.5px / 68px; 1px üst padding alt kenarlığı dengeler ve avatarı tam ortalar | browser.cjs: kesirli gerçek DOM ölçüsü, satıra sığma, ardışık satır aralığı |
| .card-name ve .card-user | 19.5 / 16.9px | 16.575 / 14.365px | browser.cjs: computed font-size (−%15) |
| .folder-wrap, .folder-header | 72px | 68px | browser.cjs: açık/kapalı DOM yüksekliği |
| .folder-title, .folder-count | 18.2 / 13px | 15.47 / 11.05px | browser.cjs: computed font-size (−%15) |
| .folder-arrow | 36.4px | 32.76px; mevcut dönüş korunur | browser.cjs: computed font-size (−%10), aşağı yön matrisi |
| .nav-container, .search-box input | Dolaylı 68px bar, 15px metin | Açıkça 68px bar, 17.25px metin | browser.cjs: bar yüksekliği, metin boyutu (+%15), düşey merkez |
| app/src/main/assets/core.js ve style.css, tools/web-bundle.json | Önceki paketler | npm run web ile yeni kaynaklardan üretim | deterministik üretim ve kaynak/paket kontrolü |

Kalıcı indeks gerçek kaynak boyutlarını tutar; 40×40 dosya üretimi bulunmuyor. Değişiklik liste görüntüleme ve sanal liste motoruyla sınırlı. Mevcut thumbnail dosyaları, indeks biçimi ve SAF tarama kodu değiştirilmedi. Bu görünüm değişikliği için yeniden tarama gerekmiyor.

Kanıt: CODE_REVIEW / UNIT_TEST. Tarayıcıda native bridge simüle edilir. Fiziksel cihaz, emülatör veya gerçek Instagram testi bu revizyon için yapılmadı. Android unit/lint ve CI yayın doğrulama sonucu verification.json içinde ayrı kayıtlıdır. Mevcut lint uyarıları gizlenmemiştir.
