# INSFAV 5.0.0 — 68px rows / 67.5px avatars

Version 5.0.0 and build 10 are unchanged. This refines the previous avatar70 release:

- Avatar: 67.5×67.5 CSS pixels; account row and folder bar: 68px.
- Virtual row offsets match the new heights; the existing 14px inter-folder gap stays.
- Display name 16.575px, username 14.365px; folder name 15.47px, count 11.05px (all −15% from the previous release).
- Folder arrow 32.76px (−10%), with its direction, placement and design preserved.
- Bottom search/info bar: explicitly 68px; search text 17.25px (+15%), centered in the same position.

The old 40×40 size was list presentation, not a stored derivative index. Source-image dimensions, original 128/256 WebP files, persistent index and read-only Rescan behavior remain unchanged. No new setting, image rewriting, re-download or queue reset was introduced. SQLite, Fetcher, JSON import and other screens are unchanged.

Validation evidence: 12 JavaScript core tests, 134 Chromium UI checks and Android unit/lint results in verification.json. Device and live Instagram testing were not performed for this sizing revision. Any older full emulator evidence belongs to the previous release; it is not represented as a test of this revision.
