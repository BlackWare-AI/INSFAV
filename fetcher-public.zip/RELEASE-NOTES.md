INSFAV **5.0.0 / build 10** korunmuştur.

- Thumbnail Fetcher, eksik görselleri **mevcut JSON listesinin sonundan başına doğru** işler. Listenin sonuna eklenen yeni favoriler önce gelir. Favoriye eklenme tarihi için yeni alan üretilmez.
- Start Missing / Resume kayıtlı başarıları ve başarısızlık geçmişini korur; açık Retry olmadan eski başarısız hesaplar tekrar denenmez.
- Üretim kodunda yalnızca QueueStore iş seçme sorguları değişti. Arayüz, avatarlar, SAF/rescan, dosyalar, worker ayarları ve hata/oturum politikaları değiştirilmedi.
- Ayrı Thumb Fetcher **0.5.0 / build 9** kodu incelendi. Entegre sürümde beş denemelik durdurma sınırı yoktur. Cihazdaki tekrar eden durmanın gerçek nedeni güncel diagnostics olmadan doğrulanamadı; sıra değişikliği bütün duraklamaların giderildiği iddiası taşımaz.

Doğrulama: **238 birim testi geçti; lint 0 hata / 34 uyarı; release derlemesi başarılı.** Testler offline/Robolectric fixture kullanır. Gerçek Instagram, emülatör veya fiziksel cihaz testi bu değişiklikte yapılmadı. Başarısız ilk test çalışmaları ve düzeltmeleri raporda açıklandı.

Kaynak: `bdcebdf2212bcacab809f96b7dac32328a29426f`  
APK SHA-256: `ba3dd8f0c8577ca52e3dd76c6d57415ed9d71b0ee4196647484d262302286c68`

APK, kaynak ZIP, test kanıtları ve sonunda tüm metin kaynaklarını içeren teknik rapor ektedir.
