INSFAV **5.0.0 / build 10** değişmedi.

Eksik profil görseli için eski sade kişi simgesi geri getirildi; eski 23 px boyutuna göre %20 büyük (**27,6 px**). Avatar kutusu, liste/matris düzeni, Bilgi modalı ve Fetcher işleyişi korunmuştur. Thumbnail dosyaları yeniden taranmadı, indirilmedi veya silinmedi.

**70 hedefli tarayıcı kontrolü ve release derlemesi geçti.** APK mevcut yayın anahtarıyla imzalandı; içerik farkları denetlendi. Yeni native kod değişikliği yok; native testler, lint ve emülatör testleri bu küçük görsel düzeltmede yeniden çalıştırılmadı. Gerçek Instagram veya fiziksel cihaz testi yapılmadı.

Kaynak: `c4e14287773860e1d256fcdab94ce0ac832a1aff`  
APK SHA-256: `24232711f4cd1f01f13e5e5bef2b6f8a4da01667bf2cb9077299aef932587687`

APK, kaynak ZIP ve sonunda tüm metin kaynak kodlarını içeren teknik rapor ektedir.
