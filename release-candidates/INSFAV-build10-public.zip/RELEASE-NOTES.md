# INSFAV 5.0.0 — Build 10

- Başarısız/atlanmış profil geçmişi uygulamada kalıcı tutulur. Start Missing ve Resume tamamlanmış başarısız istekleri tekrar denemez; Retry Skipped / Failed Profiles gerekir.
- JSON’dan çıkarılıp yeniden eklenen başarısız hesap hatırlanır; gerçekten yeni hesaplar işlenir.
- Beş timeout sonrası diğer hesapların devamı test edildi. Ekran görüntüsü tek başına cihazdaki duraksamanın kök nedenini kanıtlamaz.
- Sayaçlarla düğmeler arasına mevcut tasarımla uyumlu Current Process kartı: aktif/queued işler, son sonuç, worker bekleme geri sayımı ve ilerleme.
- Thumbnail dosyaları, Rescan ve mevcut indeks korunur. Worker sayısı, gecikme ayarı, session/rate-limit korumaları ve 45 saniye timeout değişmez.

213 Android/Robolectric testi, 118 Chromium UI kontrolü ve 35 DOM fixture geçti. Lint: 0 hata. Gerçek Instagram ve fiziksel cihaz test edilmedi.

Build 9 ile **aynı imza**, daha yüksek build 10. Build 9’dan güncellerken uygulamayı kaldırmanız gerekmez. Eski build 8’in farklı imzasıyla uyumlu değildir. Gerçek cihazda yerinde yükseltme bu çalışmada test edilmedi; imza uyumluluğu APK’lar arasında doğrulandı. Yedek almadan uygulamayı kaldırmayın veya verileri temizlemeyin.

Kaynak: `6fcaf3f61304b0e573c634cb80d6627c11cfdb97`
