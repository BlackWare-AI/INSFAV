# INSFAV 5.0.0 — Build 10 · UI & Audit Update

**Version 5.0.0, build 10 ve mevcut imza değişmedi.** Önceki build 10 APK’sı ayrı release’de korunur. Yeni dosya aynı sürüm/build ile güncellemedir; ayırt edici bilgiler kaynak commit ve SHA-256’dır.

- Unreadable/Duplicate bilgi kartları ve çözünürlük detay modalı kaldırıldı; dosya kontrolleri korundu.
- Çözünürlük sayacı, tüm taranmış görseller arasında 256×256 dışındakileri (128 dahil) sayar; duplicate/JSON’a eşleşmeyen dosyalar dahildir. Mevcut tamamlanmış SQLite kayıtları görsel açmadan kullanılabilir.
- Missing Images kartında kullanıcı adlarını klasörsüz, benzersiz ve satır satır kopyalama.
- About’ta yalnızca Application Name satırı kaldırıldı; Settings/Close yan yana. Tarih/klasör kartları yan yana, uzun klasör metni üç noktalı.
- Hafif statik modal blur ve opacity geçişi; sade Fetcher bildirimi.
- Kaynak thumbnail dosyaları ve 128/256 görüntüleme uyumluluğu korunur. Kuyruk/Retry politikası değişmedi.

**INSFAV-Teknik-Rapor.html**: indirilebilir, çevrimdışı teknik rapor. En altında tüm metin kaynakları ve çalışır ZIP indirme düğmesiyle gömülü tam kaynak arşivi vardır. Ayrı Android Studio kaynak ZIP’i de eklenmiştir.

222 native test, 125 UI kontrolü, 35 DOM fixture, browser clipboard, lint (0 hata) ve Android 14 emülatörü geçti. Gerçek uygulama köprüsü→clipboard ve 15.000 dosyada 7.500 hedef dışı 128×128 görsel doğrulandı. Fiziksel telefon ve canlı Instagram test edilmedi. Rescan’ın ek toplu-task hızlandırma denemesi kazanç göstermediği için geri alındı; kalıcı indeks reuse korundu.

Kaynak: b066f5a9af27bf711d084ae1e3ffb076c8b04ced
CI: https://github.com/BlackWare-AI/INSFAV/actions/runs/39816872755

İlk CI’de Playwright/CSP test yardımcısı hatası görüldü ve uygulama CSP’si gevşetilmeden düzeltildi. Geliştirme notları ve sınırlamalar teknik raporda bulunur. Aynı sertifika karşılaştırıldı; yeni release APK’sının gerçek cihazda yerinde kurulumu bu çalışmada denenmedi. Mevcut uygulamayı kaldırmanız gerekmez.
