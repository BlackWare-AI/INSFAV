# INSFAV 5.0.0 — Build 9

**Yeni imza anahtarıyla yayımlanmıştır. Bu APK, önceki v5.0.0 build 8 kurulumunun üzerine güncelleme olarak kurulamaz.** Önceki yayın korunur. Mevcut uygulamanızı/verilerinizi koruyun; JSON ve ayar yedeklerinizi almadan uygulamayı kaldırmayın veya verilerini temizlemeyin.

Uygulama sürümü 5.0.0 olarak kaldı; Android build/versionCode 8 → 9.

- Fetcher: Türkçe/İngilizce kapalı sayfa metinleriyle hızlı atlama; mevcut güvenilir görsel adayı varsa atlama engeli. Geçici hata metni gösteren erişilebilir profillerin de atlanabileceği, kullanıcının seçtiği politikanın bilinen riskidir.
- Rescan: tek SAF metadata listelemesi, en fazla iki doğrulama worker'ı, tipik küçük görseller için tek açma, 256 kayıtlık SQLite kontrol noktaları ve kesintiden devam.
- Rescan kaynak thumbnail dosyalarını değiştirmez veya silmez. Mevcut JSON indeksi ve 128/256 WebP uyumluluğu korunur. Fetcher worker tercihi değişmez.

## Doğrulama

196 Android birim testi, 110 Chromium UI kontrolü ve 6 Python testi geçti. LintDebug: 0 hata, 32 uyarı. Kaynak: e33c09d224628ae50bbae5bba3bba43d6a91210c; test edilen PR ağacıyla birebir aynıdır.

15.000 sentetik dosya, 1 ms modellenmiş SAF açma gecikmesi, aynı harness: ilk tarama 40,479 → 17,424 ms; sıcak 415 → 364 ms; ilk dosya açma 30.000 → 15.000; sıcak açma 0. Bunlar gerçek telefon süreleri değildir.

Android 14 emülatörü, gerçek SAF/Binder, yapay gecikme yok: ilk tarama 57,517 ms, sıcak 8,998 ms, sıcak dosya açma 0. Kaynak bytes ve lastModified korunmuştur. PSS önce/sonra 62.346 / 178.870 KiB; tüm test süreci örnekleridir, peak bellek veya bellek azalması kanıtı değildir. Mevcut offline çoklu WebView ve arka plan Fetcher senaryoları da geçti.

APK'nın non-debuggable release manifest'i, hizalaması ve v1/v2/v3 imzaları doğrulandı. Yeni imzalı release APK cihazda kurularak test edilmedi. Fiziksel cihaz ve canlı Instagram testi yapılmadı.

CI: https://github.com/BlackWare-AI/INSFAV/actions/runs/39706736573

## İndirme

Kurulum dosyası: INSFAV-5.0.0.apk. Tam kaynak: INSFAV-Android-Studio-Project.zip. SHA256SUMS ve verification.json dosyalarıyla indirilen dosyalar doğrulanabilir. İmza sertifikası fingerprint'i signing-certificate.txt içindedir. Özel imza anahtarı ve parolaları bu yayına dahil değildir.
